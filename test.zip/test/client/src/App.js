import React, { useState } from "react";
import ReactMarkdown from "react-markdown";
import axios from "axios";
import "./App.css";
function App() {
  const [message, setMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [displayedMessages, setDisplayedMessages] = useState([]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    const newMessage = {
      sender: "User",
      content: message,
    };

    // 메시지 배열에 사용자 메시지를 추가하고
    setDisplayedMessages((messages) => [...messages, newMessage]);
    setMessage(""); // 입력 필드 초기화
    setIsLoading(true); // 로딩 상태 시작

    try {
      const res = await axios.post("http://localhost:8080/api/chat", {
        message,
      });
      const newResponse = {
        sender: "AI",
        content: res.data,
      };
      // 메시지 배열에 AI 응답 추가
      setDisplayedMessages((messages) => [...messages, newResponse]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false); // 로딩 상태 종료
    }
  };

  // console.log(displayedMessages);
  // console.log(response);
  return (
    <div className="App">
      <div>
        <h2 style={{ textAlign: "center" }}>KOOK GPT</h2>

        <div className="text">
          {displayedMessages.length > 0 ? (
            displayedMessages.map((msg, index) => (
              <div
                key={index}
                className={
                  msg.sender === "User"
                    ? "user-message textBox"
                    : "ai-message textBox"
                }
              >
                <ReactMarkdown children={msg.content} />
              </div>
            ))
          ) : (
            <div
              style={{
                textAlign: "center",
                fontSize: "20px",
                lineHeight: "180px",
              }}
            >
              대화를 시작해 보세요!
            </div>
          )}
          {isLoading && <div className="spinner"></div>}
        </div>
      </div>
      <form onSubmit={handleSubmit}>
        <label>
          Message:
          <textarea
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            style={{ width: "400px" }}
          />
        </label>
        <button type="submit">Send</button>
      </form>
    </div>
  );
}

export default App;
